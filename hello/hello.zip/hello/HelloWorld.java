/* *****************************************************************************
 *  Name:              Braydon Horcoff
 *  Last modified:     October, 4, 2021
 **************************************************************************** */

public class HelloWorld {
    public static void main(String[] args) {

        System.out.printf("%s\n", "Hello, World");

    }
}
